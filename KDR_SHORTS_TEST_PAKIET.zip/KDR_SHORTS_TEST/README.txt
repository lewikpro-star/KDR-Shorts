KDR Shorts — test eksportu MP4

1. Wgraj index.html do głównego katalogu repozytorium KDR-Shorts na GitHub.
2. Poczekaj na publikację GitHub Pages.
3. Otwórz adres strony na iPhonie w Safari.
4. Naciśnij „Sprawdź i wygeneruj MP4”.
5. Zweryfikuj, czy plik KDR-Shorts-test.mp4 zapisuje się i odtwarza.

To test techniczny eksportu canvas do MP4, a nie pełna wersja generatora.
Nie zawiera jeszcze OCR, GIF-ów, biblioteki muzyki ani kompletnego edytora.
